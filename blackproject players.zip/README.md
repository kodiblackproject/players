# verified-metalliq-players
MetalliQ players verified by Q
These player files will not work on Meta-video!
